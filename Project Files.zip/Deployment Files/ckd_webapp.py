# -*- coding: utf-8 -*-
"""
Created on Sun Apr 21 15:38:43 2024

@author: nimba
"""

import numpy as np
import pickle
import streamlit as st

def ckd_prediction(sample_data):
    # Load the trained model
    loaded_model = pickle.load(open('C:/aai-pro-deploy/trained_model.sav', 'rb'))
    
    # Predict using the trained model
    prediction = loaded_model.predict(sample_data)

    if prediction[0] == 0:
        return 'The person does not have Chronic Kidney Disease'
    else:
        return 'The person has Chronic Kidney Disease'

def main():
    st.title('Chronic Kidney Disease Prediction Web APP')

    # Getting the input data from the user
    age = st.number_input('Age')
    blood_pressure = st.number_input('Blood pressure')
    specific_gravity = st.number_input('Specific gravity')
    albumin = st.number_input('Albumin')
    sugar = st.number_input('Sugar')
    red_blood_cells = st.number_input('Red Blood Cells')
    pus_cell = st.number_input('Pus cell')
    pus_cell_clumps = st.number_input('Pus cell clumps')
    bacteria = st.number_input('Bacteria')
    blood_glucose_random = st.number_input('Blood glucose')
    blood_urea = st.number_input('Blood Urea')
    serum_creatinine = st.number_input('Serum creatinine')
    sodium = st.number_input('Sodium')
    potassium = st.number_input('Potassium')
    haemoglobin = st.number_input('Haemoglobin')
    packed_cell_volume = st.number_input('Packed Cell Volume')
    white_blood_cell_count = st.number_input('White Blood Cell Count')
    red_blood_cell_count = st.number_input('Red Blood Cell Count')
    hypertension = st.number_input('Hypertension')
    diabetes_mellitus = st.number_input('Diabetes Mellitus')
    coronary_artery_disease = st.number_input('Coronary Artery Disease')
    appetite = st.number_input('Appetite')
    peda_edema = st.number_input('Peda Edema')
    aanemia = st.number_input('Aanemia')

    # Code for Prediction
    diagnosis = ''

    # Creating a button for prediction
    if st.button('CKD Test Result'):
        sample_data = [[age, blood_pressure, specific_gravity, albumin, sugar, red_blood_cells, pus_cell,
                        pus_cell_clumps, bacteria, blood_glucose_random, blood_urea, serum_creatinine, sodium,
                        potassium, haemoglobin, packed_cell_volume, white_blood_cell_count, red_blood_cell_count,
                        hypertension, diabetes_mellitus, coronary_artery_disease, appetite, peda_edema, aanemia]]
        diagnosis = ckd_prediction(sample_data)
        st.success(diagnosis)

if __name__ == '__main__':
    main()
