# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import numpy as np
import pickle 

loaded_model=pickle.load(open('C:/aai-pro-deploy/trained_model.sav','rb'))

# Sample data for prediction (excluding the target variable)
sample_data = [[48.0, 80.0, 1.020, 1.0, 0.0, 0, 1, 0, 0, 121.0, 36.0, 1.2, 140.0, 4.2, 15.4, 44.0, 7800.0, 5.2, 1, 1, 0, 0, 0, 0]]

# Convert the sample data into NumPy array
sample_data_array = np.array(sample_data)

# Predict using the trained model
prediction = loaded_model.predict(sample_data_array)

print("Prediction:", prediction)

if (prediction[0]==0):
    print('The person does not have Chronic Kidney Disease')
    
else:
    print('The person has Chronic Kidney Disease')
